python3 case-generator.py

