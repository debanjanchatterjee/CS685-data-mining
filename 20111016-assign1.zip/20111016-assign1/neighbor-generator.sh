python3 neighbor-generator.py
