python3 case-generator.py
python3 edge-generator.py
python3 neighbor-generator.py
python3 state-generator.py
python3 zscore-generator.py
python3 method-spot-generator.py
python3 top-generator.py
