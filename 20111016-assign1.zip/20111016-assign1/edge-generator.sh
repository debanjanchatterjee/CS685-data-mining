python3 edge-generator.py
