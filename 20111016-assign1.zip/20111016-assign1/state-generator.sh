python3 state-generator.py
