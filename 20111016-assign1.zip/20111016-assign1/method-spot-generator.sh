python3 method-spot-generator.py
