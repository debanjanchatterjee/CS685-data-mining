python3 zscore-generator.py
